import argparse
import json
import random
import socket
import sys
import time
from dataclasses import dataclass

import psutil
import requests


@dataclass
class Intervals:
    cpu_s: float
    ram_s: float
    disk_usage_s: float
    disk_io_s: float
    load_s: float
    net_s: float
    uptime_s: float
    db_s: float


def _now() -> float:
    return time.time()


def _sleep_until(deadline: float):
    while True:
        remaining = deadline - _now()
        if remaining <= 0:
            return
        time.sleep(min(remaining, 0.5))


def _loadavg():
    try:
        la = psutil.getloadavg()
        return {"1": float(la[0]), "5": float(la[1]), "15": float(la[2])}
    except (AttributeError, OSError):
        return {}


def _disk_partitions():
    parts = []
    for p in psutil.disk_partitions(all=False):
        if not p.mountpoint:
            continue
        parts.append(p)
    return parts


def _disk_usage_samples():
    samples = []
    for p in _disk_partitions():
        try:
            u = psutil.disk_usage(p.mountpoint)
        except OSError:
            continue
        samples.append(
            {
                "mount": p.mountpoint,
                "fstype": p.fstype or "",
                "total_bytes": int(u.total),
                "used_bytes": int(u.used),
                "percent": float(u.percent),
            }
        )
    return samples


def _disk_io():
    try:
        io = psutil.disk_io_counters()
    except Exception:
        return {}
    if io is None:
        return {}

    out = {
        "read_bytes": int(getattr(io, "read_bytes", 0) or 0),
        "write_bytes": int(getattr(io, "write_bytes", 0) or 0),
    }

    if hasattr(io, "read_time"):
        out["read_time_ms"] = int(getattr(io, "read_time", 0) or 0)
    if hasattr(io, "write_time"):
        out["write_time_ms"] = int(getattr(io, "write_time", 0) or 0)

    return out


def _net_io():
    try:
        io = psutil.net_io_counters()
    except Exception:
        return {}
    if io is None:
        return {}

    def _get(name: str):
        return int(getattr(io, name, 0) or 0)

    return {
        "bytes_sent": _get("bytes_sent"),
        "bytes_recv": _get("bytes_recv"),
        "packets_sent": _get("packets_sent"),
        "packets_recv": _get("packets_recv"),
        "errin": _get("errin"),
        "errout": _get("errout"),
        "dropin": _get("dropin"),
        "dropout": _get("dropout"),
    }


def _boot_time_epoch() -> float | None:
    try:
        return float(psutil.boot_time())
    except Exception:
        return None


def _uptime_payload() -> dict:
    boot = _boot_time_epoch()
    if boot is None:
        return {}
    return {
        "boot_time": boot,
        "uptime_seconds": int(max(0.0, _now() - boot)),
    }


def _ram_payload() -> dict:
    vm = psutil.virtual_memory()
    return {
        "total_bytes": int(vm.total),
        "used_bytes": int(vm.total - vm.available),
        "percent": float(vm.percent),
    }


def _cpu_payload() -> dict:
    return {"percent": float(psutil.cpu_percent(interval=None))}


def _post(session: requests.Session, url: str, token: str, payload: dict, timeout_s: float):
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "User-Agent": "serverwatch-agent/1.0",
    }
    resp = session.post(url, data=json.dumps(payload), headers=headers, timeout=timeout_s)
    if resp.status_code >= 400:
        raise RuntimeError(f"HTTP {resp.status_code}: {resp.text[:300]}")


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def _tcp_check(host: str, port: int, timeout_s: float) -> tuple[bool, float | None]:
    start = time.perf_counter()
    try:
        with socket.create_connection((host, port), timeout=timeout_s):
            pass
        ms = (time.perf_counter() - start) * 1000.0
        return True, ms
    except OSError:
        return False, None


def _mysql_process_up() -> bool | None:
    try:
        for p in psutil.process_iter(attrs=["name", "exe", "cmdline"]):
            name = (p.info.get("name") or "").lower()
            if name in {"mysqld", "mariadbd"}:
                return True
            exe = (p.info.get("exe") or "").lower()
            if exe.endswith("/mysqld") or exe.endswith("/mariadbd"):
                return True
            cmd = " ".join((p.info.get("cmdline") or [])).lower()
            if "mysqld" in cmd or "mariadbd" in cmd:
                return True
        return False
    except Exception:
        return None


def _mysql_avg_query_ms(cur) -> float | None:
    try:
        cur.execute(
            "SELECT SUM_SUM_TIMER_WAIT, SUM_COUNT_STAR "
            "FROM performance_schema.events_statements_summary_global_by_event_name "
            "WHERE EVENT_NAME LIKE 'statement/sql/%'"
        )
        rows = cur.fetchall() or []
    except Exception:
        return None

    total_wait = 0.0
    total_count = 0
    for r in rows:
        try:
            total_wait += float(r[0] or 0)
            total_count += int(r[1] or 0)
        except Exception:
            continue
    if total_count <= 0:
        return None
    return (total_wait / total_count) / 1e9


def _mysql_histogram_percentiles(cur) -> tuple[float | None, float | None]:
    try:
        cur.execute(
            "SELECT BUCKET_NUMBER, BUCKET_TIMER_HIGH, COUNT_BUCKET "
            "FROM performance_schema.events_statements_histogram_global ORDER BY BUCKET_NUMBER"
        )
        rows = cur.fetchall() or []
    except Exception:
        return None, None

    total = 0
    for r in rows:
        try:
            total += int(r[2] or 0)
        except Exception:
            continue
    if total <= 0:
        return None, None

    target95 = total * 0.95
    target99 = total * 0.99
    c = 0
    p95 = None
    p99 = None
    for r in rows:
        try:
            high_ps = float(r[1] or 0)
            cnt = int(r[2] or 0)
        except Exception:
            continue
        c += cnt
        if p95 is None and c >= target95:
            p95 = high_ps / 1e9
        if p99 is None and c >= target99:
            p99 = high_ps / 1e9
        if p95 is not None and p99 is not None:
            break
    return p95, p99


def _mysql_slow_count_1m(cur) -> int | None:
    try:
        cur.execute(
            "SELECT COUNT(*) FROM mysql.slow_log WHERE start_time > (NOW() - INTERVAL 1 MINUTE)"
        )
        row = cur.fetchone()
        if not row:
            return None
        return int(row[0] or 0)
    except Exception:
        return None


def _mysql_metrics(
    *,
    host: str,
    port: int,
    db_name: str,
    user: str,
    password: str,
    timeout_s: float,
    last_counters: dict | None,
    last_ts: float | None,
):
    try:
        import pymysql
    except Exception as e:
        raise RuntimeError("pymysql not installed (pip install -r requirements.txt)") from e

    process_up = _mysql_process_up()
    port_ok, port_ms = _tcp_check(host, int(port), timeout_s=timeout_s)

    connect_ok = False
    ping_ms = None

    counters: dict[str, int] = {}
    current_connections = None
    max_connections = None
    conn_usage_pct = None

    avg_query_ms = None
    p95_query_ms = None
    p99_query_ms = None
    slow_1m = None

    start = time.perf_counter()
    conn = None
    try:
        conn = pymysql.connect(
            host=host,
            port=int(port),
            user=user,
            password=password,
            database=db_name,
            connect_timeout=timeout_s,
            read_timeout=timeout_s,
            write_timeout=timeout_s,
            autocommit=True,
        )
        connect_ok = True

        with conn.cursor() as cur:
            cur.execute("SELECT 1")
            cur.fetchone()
            ping_ms = (time.perf_counter() - start) * 1000.0

            cur.execute("SHOW GLOBAL STATUS")
            for k, v in (cur.fetchall() or []):
                key = str(k)
                if key == "Threads_connected":
                    try:
                        current_connections = int(v)
                    except Exception:
                        current_connections = None
                    continue
                if key in {
                    "Queries",
                    "Questions",
                    "Com_select",
                    "Com_insert",
                    "Com_update",
                    "Com_delete",
                    "Com_commit",
                    "Com_rollback",
                }:
                    try:
                        counters[key] = int(v)
                    except Exception:
                        pass

            cur.execute("SHOW VARIABLES WHERE Variable_name='max_connections'")
            row = cur.fetchone()
            if row and len(row) >= 2:
                try:
                    max_connections = int(row[1])
                except Exception:
                    max_connections = None

            if current_connections is not None and max_connections:
                conn_usage_pct = (float(current_connections) / float(max_connections)) * 100.0

            avg_query_ms = _mysql_avg_query_ms(cur)
            p95_query_ms, p99_query_ms = _mysql_histogram_percentiles(cur)
            slow_1m = _mysql_slow_count_1m(cur)
    except Exception:
        connect_ok = False
    finally:
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass

    qps = None
    read_qps = None
    write_qps = None
    tps = None
    now_ts = _now()

    if last_counters and last_ts is not None:
        dt = max(0.001, now_ts - float(last_ts))
        try:
            dq = int(counters.get("Queries", 0)) - int(last_counters.get("Queries", 0))
            dsel = int(counters.get("Com_select", 0)) - int(last_counters.get("Com_select", 0))
            dins = int(counters.get("Com_insert", 0)) - int(last_counters.get("Com_insert", 0))
            dupd = int(counters.get("Com_update", 0)) - int(last_counters.get("Com_update", 0))
            ddel = int(counters.get("Com_delete", 0)) - int(last_counters.get("Com_delete", 0))
            dcom = int(counters.get("Com_commit", 0)) - int(last_counters.get("Com_commit", 0))
            drol = int(counters.get("Com_rollback", 0)) - int(last_counters.get("Com_rollback", 0))
            if dq >= 0:
                qps = dq / dt
            if dsel >= 0:
                read_qps = dsel / dt
            dwrite = dins + dupd + ddel
            if dwrite >= 0:
                write_qps = dwrite / dt
            dtps = dcom + drol
            if dtps >= 0:
                tps = dtps / dt
        except Exception:
            pass

    return (
        {
            "engine": "mysql",
            "process_up": process_up,
            "port_ok": port_ok,
            "port_ms": port_ms,
            "connect_ok": connect_ok,
            "ping_ms": ping_ms,
            "current_connections": current_connections,
            "max_connections": max_connections,
            "connection_usage_percent": conn_usage_pct,
            "qps": qps,
            "read_qps": read_qps,
            "write_qps": write_qps,
            "tps": tps,
            "avg_query_ms": avg_query_ms,
            "p95_query_ms": p95_query_ms,
            "p99_query_ms": p99_query_ms,
            "slow_queries_1m": slow_1m,
            "counters": counters,
        },
        counters,
        now_ts,
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="serverwatch-agent")
    parser.add_argument("--url", required=True, help="Full ingest URL, e.g. http://<django-host>:8000/api/agent/ingest/")
    parser.add_argument("--token", required=True, help="Bearer token (Server.agent_token)")
    parser.add_argument("--timeout", type=float, default=5.0)

    parser.add_argument("--cpu", type=float, default=3.0)
    parser.add_argument("--ram", type=float, default=10.0)
    parser.add_argument("--disk-usage", type=float, default=120.0)
    parser.add_argument("--disk-io", type=float, default=3.0)
    parser.add_argument("--load", type=float, default=5.0)
    parser.add_argument("--net", type=float, default=3.0)
    parser.add_argument("--uptime", type=float, default=60.0)

    parser.add_argument("--db", action="store_true", help="Enable DB health monitoring (MySQL/MariaDB)")
    parser.add_argument("--db-interval", type=float, default=5.0)
    parser.add_argument("--db-host", default="127.0.0.1")
    parser.add_argument("--db-port", type=int, default=3306)
    parser.add_argument("--db-name", default="")
    parser.add_argument("--db-user", default="")
    parser.add_argument("--db-password", default="")

    parser.add_argument("--jitter", type=float, default=0.15, help="Adds +/- jitter to schedule to prevent thundering herd")

    args = parser.parse_args(argv)

    intervals = Intervals(
        cpu_s=_clamp(float(args.cpu), 2.0, 5.0),
        ram_s=_clamp(float(args.ram), 5.0, 15.0),
        disk_usage_s=_clamp(float(args.disk_usage), 30.0, 300.0),
        disk_io_s=_clamp(float(args.disk_io), 2.0, 5.0),
        load_s=_clamp(float(args.load), 5.0, 5.0),
        net_s=_clamp(float(args.net), 2.0, 5.0),
        uptime_s=max(60.0, float(args.uptime)),
        db_s=max(2.0, float(args.db_interval)),
    )

    jitter = max(0.0, float(args.jitter))

    psutil.cpu_percent(interval=None)

    session = requests.Session()

    due = {
        "cpu": _now(),
        "ram": _now(),
        "disk_usage": _now(),
        "disk_io": _now(),
        "load": _now(),
        "net": _now(),
        "uptime": _now(),
        "db": _now(),
    }

    backoff_s = 1.0

    last_db_counters: dict | None = None
    last_db_ts: float | None = None

    while True:
        t = _now()
        payload: dict = {"ts": t}

        sent_any = False

        def _next(base: float) -> float:
            if jitter <= 0:
                return t + base
            return t + base * (1.0 + random.uniform(-jitter, jitter))

        if t >= due["cpu"]:
            payload["cpu"] = _cpu_payload()
            due["cpu"] = _next(intervals.cpu_s)
            sent_any = True

        if t >= due["ram"]:
            payload["memory"] = _ram_payload()
            due["ram"] = _next(intervals.ram_s)
            sent_any = True

        if t >= due["load"]:
            payload["load"] = _loadavg()
            due["load"] = _next(intervals.load_s)
            sent_any = True

        if t >= due["uptime"]:
            payload["uptime"] = _uptime_payload()
            due["uptime"] = _next(intervals.uptime_s)
            sent_any = True

        if t >= due["disk_io"]:
            payload["disk_io"] = _disk_io()
            due["disk_io"] = _next(intervals.disk_io_s)
            sent_any = True

        if t >= due["net"]:
            payload["network"] = _net_io()
            due["net"] = _next(intervals.net_s)
            sent_any = True

        if t >= due["disk_usage"]:
            payload["disks"] = _disk_usage_samples()
            due["disk_usage"] = _next(intervals.disk_usage_s)
            sent_any = True

        if args.db and t >= due["db"]:
            if args.db_name and args.db_user and args.db_password:
                try:
                    db_payload, last_db_counters, last_db_ts = _mysql_metrics(
                        host=str(args.db_host),
                        port=int(args.db_port),
                        db_name=str(args.db_name),
                        user=str(args.db_user),
                        password=str(args.db_password),
                        timeout_s=float(args.timeout),
                        last_counters=last_db_counters,
                        last_ts=last_db_ts,
                    )
                    payload["db"] = db_payload
                    sent_any = True
                except Exception as e:
                    sys.stderr.write("db: " + str(e) + "\n")
            else:
                port_ok, port_ms = _tcp_check(str(args.db_host), int(args.db_port), timeout_s=float(args.timeout))
                payload["db"] = {
                    "engine": "mysql",
                    "process_up": _mysql_process_up(),
                    "port_ok": port_ok,
                    "port_ms": port_ms,
                    "connect_ok": None,
                }
                sent_any = True

            due["db"] = _next(intervals.db_s)

        if sent_any:
            try:
                _post(session, args.url, args.token, payload, timeout_s=float(args.timeout))
                backoff_s = 1.0
            except Exception as e:
                sys.stderr.write(str(e) + "\n")
                backoff_s = min(60.0, backoff_s * 2.0)

        next_deadline = min(due.values())
        sleep_until = min(next_deadline, _now() + backoff_s)
        _sleep_until(sleep_until)


if __name__ == "__main__":
    raise SystemExit(main())
